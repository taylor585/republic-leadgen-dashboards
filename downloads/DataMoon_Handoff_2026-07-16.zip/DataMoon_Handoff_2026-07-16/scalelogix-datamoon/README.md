# scalelogix-datamoon

The DataMoon audience-intelligence engine as a self-contained Claude Code skill. Point it at a DataMoon
export (or any list with names + LinkedIn URLs) and it produces a **Creative Strategy Report** — exactly
what your Meta ads should say to that demographic — by reading each person's **public LinkedIn posts and
profile through Google advanced-search commands** (no LinkedIn login, no messages, sample-not-census,
aggregate-then-discard). Integrates with LeadHunter as one two-engine stack.

**Start here:** `references/DataMoon_LeadHunter_EndToEnd.md` — the full end-to-end explanation, incl. the
LeadHunter integration.
**Live dashboard:** https://taylor585.github.io/republic-leadgen-dashboards/datamoon/ (see `LINKS.md`).

## Install (make it live)
```bash
cp -R scalelogix-datamoon ~/.claude/skills/
```
Then it triggers on DataMoon / audience-intelligence tasks, or invoke `/scalelogix-datamoon`.

## Run
```bash
python3 scripts/parse_audience.py your_datamoon_export.csv --out contacts.json   # verify + strip PII
python3 scripts/sample.py contacts.json --n 25 --mode mixed --out sample.json    # pilot (or batches of 50)
python3 scripts/dork.py --from-sample sample.json                                # Google queries per contact
#   → read public posts/profiles via WebSearch; write extractions.json
python3 scripts/aggregate.py extractions.json --out fingerprint.json             # → write the report
```

## What's inside
| Path | Purpose |
|---|---|
| `SKILL.md` | workflow + YAML frontmatter |
| `references/DataMoon_LeadHunter_EndToEnd.md` | **the full technical explanation + LeadHunter integration** |
| `references/dorks.md` | the Google advanced-command method |
| `references/compliance.md` | PII rules + the account-ban tripwires |
| `references/live-batches.md` | the batches-of-50 live procedure |
| `references/report-template.md` · `extraction-schema.json` | output shapes |
| `scripts/*.py` | the runnable pipeline (stdlib only, tested on the real 36-contact CSV) |
| `test-data/*.json` | real, PII-free I/O from the run (parsed → sampled → extracted → fingerprint) |
| `examples/` | finished Alabama report, POC notes, full system plan |
| `LINKS.md` | dashboard + every URL, for Codex |

## Proven on
The 36-contact Alabama run: profile coverage ~83%, readable posts ~33%, ~1 in 6 DataMoon rows flagged,
~8% off-target — produced a usable creative brief. See `examples/` and `test-data/`.

## Relationship to `scalelogix-audience-intel`
Same engine. `scalelogix-audience-intel` is the generic audience version; **this** is the DataMoon-branded,
batteries-included package (adds the LeadHunter end-to-end doc, the real test data, and the dashboard links)
for handing to Codex or running DataMoon audiences directly.

## Safety
Never uploads to Meta. Never logs into LinkedIn. Never uses the addresses/phones/emails/income in the source
file. See `references/compliance.md`.
