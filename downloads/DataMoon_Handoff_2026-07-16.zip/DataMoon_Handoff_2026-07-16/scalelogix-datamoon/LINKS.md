# DataMoon — Links & Handoff (for Codex)

All links below are **public GitHub Pages (no login)** — Codex can fetch them directly.

## Dashboard
- **DataMoon tab (main):** https://taylor585.github.io/republic-leadgen-dashboards/datamoon/
- Command Center hub: https://taylor585.github.io/republic-leadgen-dashboards/
- Lead Tiers (DataMoon = Tier 1): https://taylor585.github.io/republic-leadgen-dashboards/research/

## Downloadable files (served from the dashboard)
- End-to-end doc: https://taylor585.github.io/republic-leadgen-dashboards/downloads/DataMoon_LeadHunter_EndToEnd.md
- This DataMoon skill (zip): https://taylor585.github.io/republic-leadgen-dashboards/downloads/scalelogix-datamoon-skill.zip
- Full-run Creative Strategy Report: https://taylor585.github.io/republic-leadgen-dashboards/downloads/Alabama_Accountants_Creative_Strategy_Report.md
- POC method notes: https://taylor585.github.io/republic-leadgen-dashboards/downloads/POC_Test_Alabama_Accountants_2026-07-16.md
- Full system plan: https://taylor585.github.io/republic-leadgen-dashboards/downloads/DataMoon_LinkedIn_System_Plan_2026-07-16.md

## Investor report (separate, public)
- https://taylor585.github.io/scalelogix-datamoon-report/

## External references
- DataMoon API docs: https://intentdocs.datamoon.com/
- Meta Custom Audience terms: https://www.facebook.com/legal/terms/customaudience

## The one-line integration with LeadHunter
DataMoon (breadth + LinkedIn URLs) and LeadHunter (real-time intent) run through the **same four-step
pipeline** (Source → Verify → Analyse → Act) and the **same scripts** in this skill; DataMoon shapes the
ad *message*, LeadHunter prioritises *who* to target. Full detail: `references/DataMoon_LeadHunter_EndToEnd.md`.
