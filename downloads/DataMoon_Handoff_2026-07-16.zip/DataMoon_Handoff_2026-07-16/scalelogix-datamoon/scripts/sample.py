#!/usr/bin/env python3
"""
sample.py — choose which contacts to analyse from a parsed audience.

Why sampling: the deliverable is the segment's AVERAGE, so ~25 (pilot) or
~250 (confident read) characterises even a 10k audience. Never a census.

Modes:
  random         pure random — best for demographic representativeness
  likely-posters top poster_score first — best for VOICE / vocabulary
  mixed          half likely-posters, half random (default) — best all-round

By default, rows flagged mismatch/no-url are excluded (they need verifying
before they can be trusted or uploaded to Meta). Pass --include-flagged to keep.

Usage:
    python3 sample.py contacts.json --n 25 --mode mixed [--seed 7] [--include-flagged]
"""
import json, argparse, random


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("contacts")
    ap.add_argument("--n", type=int, default=25)
    ap.add_argument("--mode", choices=["random", "likely-posters", "mixed"], default="mixed")
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--include-flagged", action="store_true")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    data = json.load(open(args.contacts))
    pool = data["contacts"] if isinstance(data, dict) else data
    if not args.include_flagged:
        pool = [c for c in pool if c.get("match") in ("clean", "partial")]

    rng = random.Random(args.seed)
    rng.shuffle(pool)  # break original ordering for fairness

    if args.mode == "random":
        chosen = pool[: args.n]
    elif args.mode == "likely-posters":
        chosen = sorted(pool, key=lambda c: c.get("poster_score", 0), reverse=True)[: args.n]
    else:  # mixed
        ranked = sorted(pool, key=lambda c: c.get("poster_score", 0), reverse=True)
        half = args.n // 2
        top = ranked[:half]
        rest = [c for c in pool if c not in top]
        rng.shuffle(rest)
        chosen = top + rest[: args.n - len(top)]

    out = {
        "sample_size": len(chosen),
        "requested": args.n,
        "mode": args.mode,
        "seed": args.seed,
        "note": "This is a SAMPLE, not a census. Report findings as directional; state N.",
        "contacts": chosen,
    }
    payload = json.dumps(out, indent=2)
    if args.out:
        open(args.out, "w").write(payload)
        print(f"sampled {len(chosen)} ({args.mode}) -> {args.out}")
    else:
        print(payload)


if __name__ == "__main__":
    main()
