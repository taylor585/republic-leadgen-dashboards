#!/usr/bin/env python3
"""
parse_audience.py — normalise a DataMoon (or any) contact-list CSV into the
minimal PROFESSIONAL fields the audience-intel skill needs, and flag rows whose
LinkedIn URL doesn't match the person's name (DataMoon mis-matches are common).

Data minimisation is built in: emails, phones, home addresses, income and
net-worth columns are READ PAST and never emitted. Only public professional
identity leaves this script.

Usage:
    python3 parse_audience.py <audience.csv> [--out contacts.json]

Output: JSON list of {idx, first_name, last_name, full_name, title, department,
company, company_domain, company_size, city, state, linkedin_url,
poster_score, match} — where `match` is one of clean|partial|mismatch.
"""
import csv, json, re, sys, argparse

# Titles that correlate with actually posting in public (POC finding: posts
# cluster in leadership / marketing / tech roles, not staff).
POSTER_KEYWORDS = [
    "partner", "principal", "shareholder", "owner", "founder", "president",
    "chief", "ceo", "cfo", "cio", "coo", "cmo", "director", "head of",
    "vp", "vice president", "marketing", "brand", "communications",
    "digital", "growth", "business development", "managing",
]

# Flexible column aliases so the script survives header drift.
ALIASES = {
    "first_name": ["first_name", "first", "firstname"],
    "last_name": ["last_name", "last", "lastname"],
    "title": ["job_title", "title", "jobtitle"],
    "department": ["department", "dept"],
    "company": ["company_name", "company", "employer"],
    "company_domain": ["company_domain", "domain", "website"],
    "company_size": ["company_employee_count", "employee_count", "company_size"],
    "city": ["personal_city", "city"],
    "state": ["personal_state", "state"],
    "linkedin_url": ["linkedin_url", "linkedin", "linkedinurl"],
}


def pick(row, keys):
    for k in keys:
        if k in row and row[k] not in (None, ""):
            return row[k].strip()
    return ""


def slug_of(url):
    if not url:
        return ""
    m = re.search(r"linkedin\.com/(?:in|pub)/([^/?#]+)", url, re.I)
    return (m.group(1) if m else url).lower()


def match_quality(first, last, slug):
    """clean = both names in the URL slug; partial = last only; mismatch = neither."""
    if not slug:
        return "no-url"
    f = re.sub(r"[^a-z]", "", first.lower())
    l = re.sub(r"[^a-z]", "", last.lower())
    s = re.sub(r"[^a-z]", "", slug)
    has_f = bool(f) and f in s
    has_l = bool(l) and l in s
    if has_f and has_l:
        return "clean"
    if has_l:
        return "partial"
    return "mismatch"


def poster_score(title, department):
    t = f"{title} {department}".lower()
    return sum(1 for kw in POSTER_KEYWORDS if kw in t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    contacts = []
    with open(args.csv, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        for i, row in enumerate(reader):
            get = lambda field: pick(row, ALIASES[field])
            first, last = get("first_name"), get("last_name")
            url = get("linkedin_url")
            title, dept = get("title"), get("department")
            contacts.append({
                "idx": i,
                "first_name": first,
                "last_name": last,
                "full_name": f"{first} {last}".strip(),
                "title": title,
                "department": dept,
                "company": get("company"),
                "company_domain": get("company_domain"),
                "company_size": get("company_size"),
                "city": get("city"),
                "state": get("state"),
                "linkedin_url": url,
                "poster_score": poster_score(title, dept),
                "match": match_quality(first, last, slug_of(url)),
            })

    summary = {
        "total": len(contacts),
        "clean": sum(c["match"] == "clean" for c in contacts),
        "partial": sum(c["match"] == "partial" for c in contacts),
        "mismatch": sum(c["match"] == "mismatch" for c in contacts),
        "no_url": sum(c["match"] == "no-url" for c in contacts),
        "likely_posters": sum(c["poster_score"] >= 1 for c in contacts),
    }
    out = {"summary": summary, "contacts": contacts}
    payload = json.dumps(out, indent=2)
    if args.out:
        with open(args.out, "w") as fh:
            fh.write(payload)
        print(json.dumps(summary, indent=2))
    else:
        print(payload)


if __name__ == "__main__":
    main()
