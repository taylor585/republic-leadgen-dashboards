#!/usr/bin/env python3
"""
aggregate.py — roll per-contact extraction records into ONE segment fingerprint.

It does the DETERMINISTIC part (tally themes, count post-hit rate, rank
vocabulary, summarise role mix). The agent writes the narrative Creative
Strategy Report from this + references/report-template.md. Raw per-person text
is NOT retained in the output — only aggregates (aggregate-then-discard).

Input: JSON list of records matching references/extraction-schema.json.
Usage:
    python3 aggregate.py extractions.json [--out fingerprint.json]
"""
import json, argparse
from collections import Counter


def top(counter, n):
    return [{"item": k, "count": v} for k, v in counter.most_common(n)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("extractions")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    recs = json.load(open(args.extractions))
    if isinstance(recs, dict):
        recs = recs.get("records", recs.get("contacts", []))

    n = len(recs)
    with_posts = sum(1 for r in recs if r.get("posts_found", 0) > 0)
    themes, pains, desires, values, vocab, objections, formats = (Counter() for _ in range(7))
    roles = Counter()

    for r in recs:
        for t in r.get("themes", []): themes[t.strip().lower()] += 1
        for p in r.get("pains", []): pains[p.strip().lower()] += 1
        for d in r.get("desires", []): desires[d.strip().lower()] += 1
        for v in r.get("values", []): values[v.strip().lower()] += 1
        for w in r.get("vocabulary", []): vocab[w.strip().lower()] += 1
        for o in r.get("objections", []): objections[o.strip().lower()] += 1
        for f in r.get("content_formats", []): formats[f.strip().lower()] += 1
        if r.get("seniority"): roles[r["seniority"].strip().lower()] += 1

    def pct(c):  # theme frequency as % of sample, the honest confidence signal
        return [{"item": k, "count": v, "pct": round(100 * v / n) if n else 0}
                for k, v in c.most_common(12)]

    fingerprint = {
        "sample_size": n,
        "posts_hit_rate_pct": round(100 * with_posts / n) if n else 0,
        "role_mix": top(roles, 10),
        "themes": pct(themes),
        "pains": pct(pains),
        "desires": pct(desires),
        "values": pct(values),
        "objections": pct(objections),
        "content_formats": pct(formats),
        "vocabulary": top(vocab, 25),
        "confidence_note": (
            "Directional. Unit of confidence is the PERSON (n=%d), not the post. "
            "A theme in >=~two-thirds of the sample is a strong signal; a theme in "
            "a handful is a hypothesis, not a finding." % n
        ),
    }
    payload = json.dumps(fingerprint, indent=2)
    if args.out:
        open(args.out, "w").write(payload)
        print(f"fingerprint from {n} records ({fingerprint['posts_hit_rate_pct']}% had posts) -> {args.out}")
    else:
        print(payload)


if __name__ == "__main__":
    main()
