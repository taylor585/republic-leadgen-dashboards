#!/usr/bin/env python3
"""
dork.py — generate the Google advanced-search queries used to read a contact's
PUBLIC LinkedIn posts and profile via the search index (never touching a
LinkedIn login). Validated in the Alabama-accountants POC.

Usage:
    python3 dork.py --name "Nick Cadden" --firm "Carr Riggs & Ingram" --city Birmingham --state AL
    python3 dork.py --from-sample sample.json     # prints queries for every contact
"""
import argparse, json, re


def niche_terms(firm, title):
    t = f"{firm} {title}".lower()
    terms = []
    for kw, tag in [
        ("cpa", "CPA"), ("account", "accountant"), ("tax", "tax"),
        ("audit", "audit"), ("advisor", "advisory"), ("wealth", "wealth"),
        ("financial", "finance"),
    ]:
        if kw in t:
            terms.append(tag)
    return terms[:3]


def queries(name, firm="", city="", state="", title=""):
    firmshort = re.split(r"[,&]", firm)[0].strip() if firm else ""
    nt = niche_terms(firm, title)
    q = [
        # 1. Their public POSTS (primary goal — up to 10)
        f'site:linkedin.com/posts "{name}"',
        # 2. Posts, disambiguated for common names
        f'site:linkedin.com/posts "{name}" ({" OR ".join(nt) or firmshort or state})'.strip(),
        # 3. The PROFILE itself (near-100% hit rate — coverage even when they don't post)
        f'site:linkedin.com/in "{name}" {city} {state} {firmshort}'.strip(),
        # 4. Public professional signal beyond LinkedIn (firm bio, press, awards, talks)
        f'"{name}" {firmshort} ({" OR ".join(nt) or "accountant"})'.strip(),
    ]
    # collapse whitespace
    return [re.sub(r"\s+", " ", x).strip() for x in q if x]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name"); ap.add_argument("--firm", default="")
    ap.add_argument("--city", default=""); ap.add_argument("--state", default="")
    ap.add_argument("--title", default="")
    ap.add_argument("--from-sample", default="")
    args = ap.parse_args()

    if args.from_sample:
        data = json.load(open(args.from_sample))
        pool = data["contacts"] if isinstance(data, dict) else data
        for c in pool:
            print(f"### {c['full_name']} — {c.get('title','')} @ {c.get('company','')}")
            for query in queries(c["full_name"], c.get("company", ""), c.get("city", ""),
                                  c.get("state", ""), c.get("title", "")):
                print("  " + query)
            print()
    elif args.name:
        for query in queries(args.name, args.firm, args.city, args.state, args.title):
            print(query)
    else:
        ap.error("pass --name or --from-sample")


if __name__ == "__main__":
    main()
