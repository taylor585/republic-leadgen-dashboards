# Live operation — batches of 50

The pilot proves the pipeline on ~25. Live, you run larger audiences in **batches
of 50** so the work is paced, checkpointed, and cheap to stop.

## Why 50
- **Confidence:** you don't need everyone. A random 250 (five batches) reads a
  10,000-person audience to ~±6% at 95%. One batch of 50 already gives a solid
  directional fingerprint; each further batch tightens it.
- **Pacing:** 50 is a comfortable unit for the Google-index reads without hammering
  the search layer — space queries human-paced (a few seconds apart); if using the
  Chrome MCP, keep well under ~50 searches/hour to avoid Google's own bot-block.
- **Checkpointing:** aggregate after each batch. If the fingerprint has stopped
  moving between batches (themes stable, no new vocabulary), **stop** — you've
  saturated the segment. Log how many batches you ran and why you stopped.

## The loop
```
parse_audience.py  →  contacts.json (once per audience; flags mismatches)
for each batch of 50:
    sample.py --n 50 --mode mixed --seed <batch#>     # no overlap across batches
    dork.py --from-sample batch.json                  # queries per contact
    → read public posts+profile via WebSearch/Chrome   # Stage 3 extraction
    aggregate.py  batch_extractions.json → batch_fingerprint.json
    merge into running fingerprint; compare to previous
    if stable for 1–2 batches: STOP
discard raw extractions; keep fingerprint + report
```

## Expected economics per batch of 50 (Google-index method)
- ~50 profile confirmations (near-100% found) + ~18–20 with readable posts (~38%).
- No provider cost on the Google path (WebSearch), or a small SERP-API cost at scale.
- Wall-clock: minutes, not hours, when run via WebSearch; longer if paced through a real browser.

## Scaling knobs
- **More voice** (vocabulary/tone): `--mode likely-posters`, or raise N.
- **More representativeness** (demographics): `--mode random`.
- **Firm the numbers**: run more batches until themes stabilise (target N≈250 for quotable %).
- **Verify-before-upload**: only `match: clean` rows are Meta-eligible without a manual check.
