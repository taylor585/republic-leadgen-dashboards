# Creative Strategy Report — TEMPLATE

Fill this from the aggregate fingerprint (aggregate.py output) + the per-contact
extractions. Structured so a copywriter, a video editor and a static designer can
each act without re-reading anything. Every claim carries a frequency so nobody
mistakes a hypothesis for a fact.

---

# Creative Strategy Report — {AUDIENCE NAME}
**Segment:** {who, filters used} · **Sample:** {N} of {audience size} ({mode}) · **Method:** Google-index (no LinkedIn login) · **Date:** {date}
**Confidence:** {directional / firm} — unit of confidence is the person (n={N}); {post-hit-rate}% had readable posts.

> Aggregate intelligence only. No individual dossiers retained; raw contact PII was not used.

## 1. Segment snapshot
- Who they are, seniority mix, top firms/roles, geography.
- Post-hit rate and what that implies (who in this segment actually posts).

## 2. Psychographic fingerprint
Ranked, each with a frequency and 2–3 *verbatim* phrases they actually use:
- **Dominant pains** — {pain} (~{x}% of sample) · "verbatim"
- **Desires / aspirations** — …
- **Fears** — …
- **Identity markers** — how they see themselves
- **Values** — what earns their trust

## 3. Awareness & sophistication (Schwartz)
- Where the segment sits (problem-aware / solution-aware / most-aware) → the angle this dictates.
- How many competing claims they've already heard → how much proof is required.

## 4. Message map
The 3–5 angles most likely to land. For each: the pain it answers, the objection it pre-empts, the proof it needs.

## 5. Asset-level direction
- **Hooks (first 3s):** 8–10, written in their vocabulary.
- **Ad copy:** primary-text + headline patterns, tone, reading level, what to never say.
- **Video / VSL scripts:** narrative arc, the proof points that matter to *them*, objections to handle, CTA framing.
- **Static images:** concepts, visual cues, the identity to reflect, text-overlay lines.
- **Offer / CTA framing:** what the primary action should feel like for this segment.

## 6. Do-not-say list
Clichés, wrong assumptions, and compliance-sensitive claims for this vertical.

## 7. Method & governance footer
Sample size, mode, provider/fetch method, date. Note: aggregate only, raw discarded, DataMoon rows with match≠clean were verified/excluded. Reminder of the Meta rights-attestation gate before any upload.
