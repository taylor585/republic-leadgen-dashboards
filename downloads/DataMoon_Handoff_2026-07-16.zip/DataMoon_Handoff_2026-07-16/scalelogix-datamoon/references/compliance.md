# Compliance gates — read before running, non-negotiable

This skill is safe by construction *only if* these hold. They are ranked by how
badly they can hurt the business.

## PII minimisation (always on)
The input CSV contains home addresses, personal phones/emails, income and
net-worth. **Never** read, echo, store, or put those in any output.
`parse_audience.py` already strips them — work only from its output (name, title,
firm, city/state, LinkedIn URL). Reports use public professional identity only.

## Tripwire 1 — the Meta upload (biggest, separate from LinkedIn)
Meta's Custom Audience terms require the advertiser to warrant they have *"all
necessary rights and permissions and a lawful basis"* for uploaded contact data.
A cold, third-party-sourced list (DataMoon) is the classic trigger for audience
rejection and, repeated, account restriction.
- **This skill never uploads to Meta.** Producing the creative brief is safe; the
  upload is a separate, deliberate, human step.
- Before any upload: a person confirms lawful basis, that it's not a restricted
  category (health, financial hardship, credit, etc.), and that they're
  comfortable given the ad account's history. Rows with `match != clean` must be
  verified or dropped first — a mismatched row is the wrong human.

## Tripwire 2 — LinkedIn automated access
LinkedIn's User Agreement prohibits automated access; Proxycurl was sued and shut
down (2025). This skill **does not automate against LinkedIn** — it reads Google's
public index. Do not "upgrade" it to a cookie-session scraper for scale without a
burner account and explicit accepted risk. Reading public data is defensible
(*hiQ v. LinkedIn*); the residual risk is an account ban, which the Google path avoids.

## Privacy law
UK-based controller, US targets → UK GDPR + CCPA/CPRA apply. Mitigation is
structural: **sample → aggregate → discard the raw.** Keep only the fingerprint
and the report. Do not build a permanent per-person dossier store.

## The vendor test (if you ever add a paid provider)
"Can they explain in plain language how they collected this data, and have they
published that explanation?" Yes → usable (Bright Data, People Data Labs).
Fake accounts / undisclosed broker chains → out.
