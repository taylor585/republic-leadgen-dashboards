# Google-index fetch — the dork patterns

We read each person's PUBLIC posts and profile through Google's index. We never
log into LinkedIn, never automate against it, never message anyone. Direct
LinkedIn fetches return **HTTP 999** (hard block) — Google is the only read path,
confirmed in the Alabama POC.

## The four queries per contact (see scripts/dork.py)
1. **Posts** — `site:linkedin.com/posts "First Last"`
2. **Posts, disambiguated** — `site:linkedin.com/posts "First Last" (CPA OR tax OR <state>)`
   (needed for common names — "Keith Miller" returns dozens without it)
3. **Profile** — `site:linkedin.com/in "First Last" <city> <state> <firm>` (near-100% hit)
4. **Beyond LinkedIn** — `"First Last" <firm> (accountant OR CPA)` → firm bios, press, awards, talks

## How to run them
- **Preferred:** the `WebSearch` tool with `allowed_domains: ["linkedin.com"]` for 1–3, and unrestricted for 4. It reads Google's index directly with no browser and no CAPTCHA.
- **Alternative:** the Chrome MCP (`mcp__claude-in-chrome__*`) running the same queries human-paced in the user's real browser — use when WebSearch coverage is thin or you need to open a specific public post.
- **At scale:** a SERP API (SerpAPI, Serper.dev) behind the same query builder.

## Reading the results
- Post URLs look like `linkedin.com/posts/<slug>_<text>-activity-<id>` — the `<text>` fragment in the result title/snippet usually reveals the post's topic even without opening it. Capture the topic; you rarely need the full body.
- Profile results confirm identity (title, firm, location) → coverage even when there are no posts.
- **Blend both:** posts give voice/vocabulary; profile + query 4 give coverage for the ~60% who don't post. A contact with 0 posts is still analysable from public professional signal — mark `confidence: profile-based`.

## Coverage, not compliance, is the limit
Only public, indexed content appears — expect a **post-hit rate around 35–40%** for professional segments (POC finding). That's fine: the fingerprint is an aggregate. If a run needs more voice, raise N or bias the sample toward likely-posters (`sample.py --mode likely-posters`).
