---
name: scalelogix-datamoon
description: The DataMoon audience-intelligence engine. Takes a DataMoon export (or any contact list with names + LinkedIn URLs), reads each person's PUBLIC LinkedIn posts and profile through Google advanced-search commands (never logging into LinkedIn, never messaging anyone), and produces an aggregate Creative Strategy Report telling you exactly how to advertise to that demographic on Meta. Integrates with LeadHunter as the two-engine lead-intelligence stack (DataMoon = breadth + LinkedIn URLs, LeadHunter = real-time intent) feeding one shared pipeline and one Meta ad workflow. Samples rather than scraping everyone, aggregates, discards the raw, and flags DataMoon's data-quality errors automatically. Use for: DataMoon audience analysis, DataMoon→LinkedIn→Meta, audience intelligence, creative strategy from a list, psychographic/persona research, LeadHunter integration, or preparing a Meta custom audience. Trigger on: DataMoon, LeadHunter integration, audience intelligence, "what do these people care about", creative strategy from an audience, psychographic fingerprint, message-market fit.
---

# ScaleLogix DataMoon

The DataMoon-branded, batteries-included version of our audience-intelligence engine. Point it at a
DataMoon export and it returns a creative brief — exactly what your Meta ads should say to that
demographic — built from what those people actually post about. Proven live on 36 Alabama accountants.

**Full technical explanation (read this first):** `references/DataMoon_LeadHunter_EndToEnd.md`.
**Live dashboard (public, no login):** https://taylor585.github.io/republic-leadgen-dashboards/datamoon/

## The one idea
Deliverable = a segment **average**, not individual dossiers. So: **sample → analyse → aggregate →
discard the raw → keep only the fingerprint.** Value lives in the aggregate; risk lives in the raw.

## How DataMoon fits with LeadHunter
Two engines, one process (Source → Verify → Analyse → Act). **DataMoon** supplies breadth and a
**LinkedIn URL per row**; **LeadHunter** supplies real-time intent. Both feed the *same* scripts below
and the *same* Meta workflow — DataMoon shapes the message, LeadHunter prioritises the spend. Detail in
the end-to-end doc.

## Guardrails (read `references/compliance.md`)
1. **PII minimisation** — `parse_audience.py` keeps only public professional fields; addresses, phones,
   emails, income are dropped.
2. **No LinkedIn login, no messages** — Google index only (direct LinkedIn = HTTP 999).
3. **Never uploads to Meta** — that's a separate human step behind a rights-attestation gate.

## Workflow
```
# 1. Verify — normalise + flag DataMoon's bad rows (~1 in 6 in the test)
python3 scripts/parse_audience.py <datamoon_export.csv> --out contacts.json

# 2. Sample — pilot 25, or live batches of 50 (see references/live-batches.md)
python3 scripts/sample.py contacts.json --n 25 --mode mixed --out sample.json

# 3. Analyse — generate the Google advanced-command queries, then read the results
python3 scripts/dork.py --from-sample sample.json
#   run each query with WebSearch (allowed_domains:["linkedin.com"] for posts/profile),
#   capture per-contact records per references/extraction-schema.json (posts=voice, profile=coverage)

# 4. Aggregate + report
python3 scripts/aggregate.py extractions.json --out fingerprint.json
#   write the Creative Strategy Report from references/report-template.md, then discard the raw
```

## Live operation
Run real audiences in **batches of 50**, aggregating after each and stopping when the fingerprint
stabilises. See `references/live-batches.md`.

## Effectiveness (proven, 36-contact run)
Profile coverage ~83% · readable posts ~33% (cluster in leaders/marketers/tech) · DataMoon errors
~1 in 6 caught automatically · off-target ~8%. Produced a usable creative brief. Real I/O in
`test-data/`, finished report in `examples/`.

## Files
- `references/` — end-to-end doc, dorks method, compliance, live-batches, report template, schema
- `scripts/` — parse_audience · sample · dork · aggregate (stdlib only, tested on the real CSV)
- `test-data/` — real PII-free I/O from the run
- `examples/` — the finished Alabama report, POC notes, full system plan
- `LINKS.md` — the dashboard + all URLs
