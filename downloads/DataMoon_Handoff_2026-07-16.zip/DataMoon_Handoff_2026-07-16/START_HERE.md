# DataMoon — Complete Handoff Bundle
**ScaleLogix AI · 16 July 2026 · everything for Codex in one folder**

Live dashboard (public, no login): **https://taylor585.github.io/republic-leadgen-dashboards/datamoon/**

## What's in here
| File / folder | What it is |
|---|---|
| `DataMoon_LeadHunter_EndToEnd.md` | **Read first.** Exactly how it works end-to-end and how it integrates with LeadHunter (same Google advanced-command process as LinkedIn). |
| `scalelogix-datamoon/` | **The installable skill** — SKILL.md (YAML), runnable scripts, references, real PII-free test data, examples. Install: `cp -R scalelogix-datamoon ~/.claude/skills/` |
| `Alabama_Accountants_Creative_Strategy_Report.md` | The finished full-run creative brief (the deliverable the engine produces). |
| `POC_Test_Alabama_Accountants.md` | Method notes from the proof-of-concept. |
| `DataMoon_System_Plan.md` | The full system plan (automation options, compliance, build phases). |
| `DataMoon_dashboard_tab.html` | **Offline copy of the dashboard tab** — double-click to open. Nav + download buttons point to the live public site. |

## Suggested reading order for Codex
1. `DataMoon_LeadHunter_EndToEnd.md` — the whole picture + LeadHunter integration.
2. `scalelogix-datamoon/SKILL.md` — the workflow.
3. `scalelogix-datamoon/test-data/*.json` — real input/output shapes (parsed → sampled → extracted → fingerprint).
4. `Alabama_Accountants_Creative_Strategy_Report.md` — what the pipeline produces.

## The one-line summary
DataMoon supplies a filtered audience with a LinkedIn URL per row; we read each person's **public** LinkedIn posts/profile through **Google advanced-search commands** (never logging into LinkedIn), aggregate what the segment cares about, and output a creative brief for Meta ads. LeadHunter is the sibling engine (real-time intent) — both run the **same four-step pipeline and scripts**: DataMoon shapes the message, LeadHunter prioritises the spend.

## Safety notes (already enforced in the skill)
- No LinkedIn login, no messages sent.
- Source-file PII (addresses, phones, emails, income) is stripped at parse time — the bundled `test-data/` is public-professional-fields only.
- The skill never uploads to Meta; that's a separate human step behind a rights-attestation gate.
