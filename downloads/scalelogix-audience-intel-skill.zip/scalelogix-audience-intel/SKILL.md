---
name: scalelogix-audience-intel
description: Turn a DataMoon (or any contact-list CSV with names + LinkedIn URLs) audience into an aggregate Creative Strategy Report that says exactly how to advertise to that demographic on Meta — hooks, ad copy, video scripts, static concepts, CTA, do-not-say. Reads each person's PUBLIC LinkedIn posts and profile through Google's search index only (never logs into LinkedIn, never messages anyone, HTTP-999-safe). Samples rather than scraping everyone, aggregates, and discards the raw. Use for audience intelligence, psychographic/persona research, creative strategy, DataMoon audience analysis, ICP messaging, or preparing a Meta custom audience. Trigger on: DataMoon, audience analysis, LinkedIn audience, creative strategy from an audience, "what do these people care about", psychographic fingerprint, persona research, message-market fit for a list.
---

# ScaleLogix Audience Intel

Take an audience of real people and return the one thing that makes a Meta campaign
convert: **what this demographic actually cares about, in their own words, and exactly
how to say it back to them.** Built for the DataMoon → LinkedIn → Meta pipeline and
proven on the Alabama-accountants POC (see `examples/`).

## The one idea
The deliverable is a segment **average**, not a pile of individual dossiers. So we
**sample → analyse → aggregate → discard the raw → keep only the fingerprint.** The
value (creative direction) lives in the aggregate; the risk (ToS, privacy, ban surface)
lives in the per-person raw data. Keep the value, delete the risk.

## Before you start — load the guardrails
Read `references/compliance.md`. Three rules govern everything:
1. **PII minimisation** — never read/echo/store the home addresses, phones, emails,
   income or net-worth in the CSV. `parse_audience.py` strips them; work only from its output.
2. **No LinkedIn login, ever** — read Google's public index (direct LinkedIn = HTTP 999).
3. **This skill never uploads to Meta** — the brief is safe; the upload is a separate
   human step behind a rights-attestation gate.

## Inputs
- A CSV with at least: first name, last name, LinkedIn URL, job title, company, city/state.
  (DataMoon exports match out of the box; column aliases handled in `parse_audience.py`.)
- Optional: audience description, target N, and whether the goal is **voice** (vocabulary/tone)
  or **demographics** (representativeness).

## Workflow

### 1 · Parse & verify the audience
```
python3 scripts/parse_audience.py <audience.csv> --out contacts.json
```
Prints a summary and flags rows whose LinkedIn URL doesn't match the name
(`clean` / `partial` / `mismatch` / `no-url`). **DataMoon rows are not facts** — the POC
found ~1 in 6 mis-matched. Rows that aren't `clean` are excluded from sampling by default
and must be verified before anyone trusts or uploads them.

### 2 · Sample (never a census)
```
python3 scripts/sample.py contacts.json --n 25 --mode mixed --out sample.json
```
- Pilot: `--n 25`. Confident read: `--n 250`. Live: batches of 50 (see `references/live-batches.md`).
- `--mode likely-posters` when you want **voice**; `--mode random` for **demographics**;
  `mixed` (default) is the all-rounder.

### 3 · Read each contact's public signal via Google
For each sampled contact, generate queries:
```
python3 scripts/dork.py --from-sample sample.json
```
Run them with the **WebSearch** tool (`allowed_domains: ["linkedin.com"]` for the post/profile
queries; unrestricted for the "beyond LinkedIn" query), or the **Chrome MCP** for anything
WebSearch misses. See `references/dorks.md`. For each contact, capture an extraction record
matching `references/extraction-schema.json`:
- their **posts** (topic of each, up to 10) → themes, pains, desires, objections, values, **vocabulary**;
- if they don't post (~60% won't), fall back to **public professional signal** (firm bio, awards,
  press, talks) and mark `confidence: profile-based`. Posts give voice; profiles give coverage — **blend both.**
Do **not** record anyone's private life; capture professional topics and language only.

### 4 · Aggregate into the fingerprint
```
python3 scripts/aggregate.py extractions.json --out fingerprint.json
```
Produces theme/pain/desire/value frequencies (as % of sample), the post-hit rate, role mix,
and ranked vocabulary. This is the deterministic core; you write the narrative from it.

### 5 · Write the Creative Strategy Report
Follow `references/report-template.md`. Every claim carries a frequency so a hypothesis is
never mistaken for a fact. Ground the copy angles in Schwartz awareness/sophistication and,
if available, hand off to the `world-class-copywriting` and b2c creative skills for execution.

### 6 · Dispose
Delete the raw extractions and any per-person notes. Keep only `fingerprint.json` and the
report. State the sample size, mode and method in the report footer.

## Live operation
For real audiences, run **batches of 50**, aggregating after each and stopping when the
fingerprint stabilises. Full procedure and economics in `references/live-batches.md`.

## How well it works (POC, Alabama accountants)
- **Profile-match hit rate ≈ 100%** — Google finds the right person almost every time.
- **Post-hit rate ≈ 38%** — real posts cluster in partners/leaders/marketers/tech roles;
  staff rarely post. The blend (posts + public professional signal) keeps coverage at ~100%.
- **DataMoon quality** — ~1 in 6 rows had name↔URL or location mismatches; verification is not optional.
- **Output** — even at n=5, a coherent, usable creative brief. See `examples/`.

## Files
- `scripts/parse_audience.py` · `sample.py` · `dork.py` · `aggregate.py`
- `references/compliance.md` · `dorks.md` · `report-template.md` · `extraction-schema.json` · `live-batches.md`
- `examples/` — the finished Alabama-accountants report + the raw POC method notes
