# scalelogix-audience-intel

A Claude Code skill: turn a **DataMoon** (or any contact-list) audience into an
aggregate **Creative Strategy Report** — exactly how to advertise to that
demographic on Meta — by reading each person's **public LinkedIn posts + profile
through Google's index** (no LinkedIn login, no messages, sample-not-census,
aggregate-then-discard).

## Install (make it live)
```bash
cp -R "scalelogix-audience-intel" ~/.claude/skills/
```
Then it triggers automatically on audience-analysis tasks, or invoke `/scalelogix-audience-intel`.

## Quick start
```bash
cd ~/.claude/skills/scalelogix-audience-intel
python3 scripts/parse_audience.py your_audience.csv --out contacts.json     # normalise + flag DataMoon mismatches
python3 scripts/sample.py contacts.json --n 25 --mode mixed --out sample.json
python3 scripts/dork.py --from-sample sample.json                            # Google queries per contact
#   → read public posts/profiles via WebSearch or the Chrome MCP; write extractions.json
python3 scripts/aggregate.py extractions.json --out fingerprint.json         # roll up to the segment fingerprint
#   → write the Creative Strategy Report from references/report-template.md
```

## What's inside
| Path | Purpose |
|---|---|
| `SKILL.md` | The workflow the agent follows |
| `scripts/parse_audience.py` | CSV → minimal professional fields; flags name↔URL mismatches; strips PII |
| `scripts/sample.py` | Pick N (pilot 25 / live batches of 50); voice vs demographic modes |
| `scripts/dork.py` | The validated Google advanced-search queries per contact |
| `scripts/aggregate.py` | Extractions → fingerprint (theme %s, post-hit rate, vocabulary) |
| `references/compliance.md` | PII rules + the two account-ban tripwires (read first) |
| `references/dorks.md` | How the Google-index fetch works |
| `references/report-template.md` | The Creative Strategy Report structure |
| `references/extraction-schema.json` | Per-contact record shape |
| `references/live-batches.md` | The batches-of-50 live operating procedure |
| `examples/` | Finished Alabama-accountants report + POC method notes |

## Proven on
The Alabama-accountants POC (36 DataMoon contacts): profile-match ≈100%,
post-hit ≈38% (clustered in leaders/marketers/tech), ~1 in 6 DataMoon rows
mismatched. Produced a usable creative brief at n=5. See `examples/`.

## Safety
Never uploads to Meta. Never logs into LinkedIn. Never uses the addresses/phones/
emails/income in the source file. See `references/compliance.md`.
